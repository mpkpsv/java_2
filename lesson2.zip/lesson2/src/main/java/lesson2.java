package PACKAGE_NAME;public class lesson2 {
}
